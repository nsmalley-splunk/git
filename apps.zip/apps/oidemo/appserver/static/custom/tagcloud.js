define(function(require, module){
    require('css!./tagcloud.css');
	var _ = require('underscore'), $ = require('jquery');
	var SimpleSplunkView = require('splunkjs/mvc/simplesplunkview');
	var Drilldown = require('splunkjs/mvc/drilldown');

	require('css!./tagcloud.css');

	return SimpleSplunkView.extend({
        moduleId: module.id,
		className: 'tagcloud-viz',
		options: {
			labelField: 'label',
			magnitudeField: 'count',
			minFontSize: 8,
			maxFontSize: 36,
			data: 'preview'
		},
		output_mode: 'json',
		events: {
			'click a': function(e) {
				e.preventDefault();
				Drilldown.handleDrilldown({
					name: this.settings.get('labelField'),
					value: $.trim($(e.target).text())
				}, 'row', this.manager);
			}
		},
        createView: function() {
        	return true;
        },
        updateView: function(viz, data) {
        	var labelField = this.settings.get('labelField');
        	var magnitudeField = this.settings.get('magnitudeField');
        	var minFontSize = parseFloat(this.settings.get('minFontSize'));
        	var maxFontSize = parseFloat(this.settings.get('maxFontSize'));

        	var el = this.$el.empty();
        	var minMagnitude = Infinity, maxMagnitude = -Infinity;

        	_(data).chain().map(function(result) {
        		var magnitude = parseFloat(result[magnitudeField]);
        		minMagnitude = magnitude < minMagnitude ? magnitude : minMagnitude;
        		maxMagnitude = magnitude > maxMagnitude ? magnitude : maxMagnitude;
				return {
					label: result[labelField],
					magnitude: magnitude
				};
        	}).each(function(result) {
        		var size = minFontSize +
        			(
        				(result.magnitude - minMagnitude) / maxMagnitude
        				* (maxFontSize - minFontSize)
    				);


        		$('<a class="link" href="#" /> ').text(result.label + ' ').css({
        			'font-size': size
        		}).appendTo(el);
        	});
        },
        getResultsLinkOptions: function() {
        	return {};
        }
	});

});
